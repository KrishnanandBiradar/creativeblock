import os


class Config(object):
    DEBUG = False
    TESTING = False

class ProdConfig(Config):
    pass

class DevConfig(Config):
    pass


class TestingConfig(Config):
    pass

def get_env_var():
    env = os.getenv('TDEX_ENV') or None
    if env == 'dev':
        print("Using TDEX_ENV=dev")
        return DevConfig
    elif env == 'qa':
        print("Using TDEX_ENV=qa")
        return TestingConfig
    else:
        print("Using Default TDEX_ENV=prod")
        return ProdConfig

config = get_env_var()