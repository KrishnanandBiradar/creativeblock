export FLASK_APP=run.py
export FLASK_ENV=development
export TDEX_ENV=dev
flask run