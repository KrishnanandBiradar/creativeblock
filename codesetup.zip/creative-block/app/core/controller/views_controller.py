import os, json
from app import app
from flask import render_template, jsonify

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/bp-json/', methods=['GET'])
def json_view():
    print('reading json file ...')
    SITE_ROOT = os.path.realpath(os.path.dirname(__file__))
    json_url = os.path.join(SITE_ROOT, "data", "bp.json")

    with open(json_url) as myfile:
        jsondata = json.load(myfile)
    print('read json file ...')

    json_str = jsonify(jsondata)
    return json_str