export FLASK_APP=run.py
export FLASK_ENV=development
export TDEX_ENV=dev
gunicorn --workers=3 --bind 127.0.0.1:5000 run:app
