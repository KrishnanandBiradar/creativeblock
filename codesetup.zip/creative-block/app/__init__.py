from flask import Flask
import os

from werkzeug.exceptions import ExpectationFailed

app = Flask(__name__)

from app.core.controller import views_controller